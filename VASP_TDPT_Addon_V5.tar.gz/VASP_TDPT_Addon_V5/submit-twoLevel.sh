#!/bin/bash

#SBATCH --job-name=V2_Test
#SBATCH --qos=regular
#SBATCH --time=24:00:00
#SBATCH --constraint=cpu
#SBATCH --nodes=1
#SBATCH --account=m3972

cd $SLURM_SUBMIT_DIR
module load vasp/6.3.2-gpu

./twoLevelSystem.sh

