#!/bin/bash


for amplitude in 0.0001 0.00001 0.000001 0.0000001
do
    for omega in {355..364}
    do
	dirName="E${amplitude}_w0.$omega"
	if [ -e "$dirName" ];
	then
	    echo "directory $dirName found, skipping creation"
	else
	    mkdir $dirName
	    cp * $dirName    
	fi
	cd $dirName
	sed -i "s|#PBS -N V2_Debug|#PBS -N 2Band_$dirName|g" job.pbs #CCAST
	#sed -i "s|#SBATCH --job-name=V2_Test|#SBATCH --job-name=$dirName|g" submit-twoLevel.sh #NERSC
	wd=$(pwd)
	scriptName=${wd}/twoLevelSystem.sh
	sed -i "s|/mmfs1/scratch/dmitri.kilin/Landon/VASP_Addon/V2_Debug/twoLevelSystem.sh|${scriptName}|g" job.pbs #CCAST
	#NERSC: nothing needs to be done
	sed -i "s|E = <tmp>|E = $amplitude|g" PHOTCAR
	sed -i "s|omega = <tmp>|omega = 0.$omega|g" PHOTCAR
	gfortran -O3 firstTimeStep.f -o firstTimeStep.exe
	qsub job.pbs #CCAST
	#sbatch submit-twoLevel.sh #NERSC
	cd ..
    done
done
