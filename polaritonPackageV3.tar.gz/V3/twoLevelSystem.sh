##################################################
#!!!!! Describe this program !!!!!#
##################################################




########## Run initial VASP optimization ##########

mpiexec -machinefile $PBS_NODEFILE -np $NUM_PROC vasp_gam > outputFile.txt # CCAST
#srun -n 68 vasp_gam # NERSC





########## Extract data from optimized WAVECAR ##########
########## Then update the WAVECAR ##########


fileName='dataFile.txt'

if [ -f "$fileName" ];
then
    echo "$fileName found, skipping initialization."
    echo "Continuing job."
else
    #cp WAVECAR WAVECAR_00000
    cp WAVECAR WAVECAR_OLD
    ./firstTimeStep.exe >> outputFile.txt # CCAST
    #./firstTimeStep.exe # NERSC
    if [ $? -ne 0 ];
    then
	echo "firstTimeStep.exe crashed. Terminating twoLevelSystem.sh"
	exit
    else
	gfortran -O3 updateWAVECAR.f -o updateWAVECAR.exe
    fi
fi




########## Iterate forward through time ##########

for i in {1..100000}
do
    j=$(printf "%.5d" "$i")
    echo t$j
    #cp WAVECAR WAVECAR_$j
    mpiexec -machinefile $PBS_NODEFILE -np $NUM_PROC vasp_gam >> outputFile.txt # CCAST
    #srun -n 68 vasp_gam # NERSC
    cp WAVECAR WAVECAR_OLD
    ./updateWAVECAR.exe >> outputFile.txt # CCAST
    #./updateWAVECAR.exe # NERSC
    if [ $? -ne 0 ];
    then
       echo "updateWAVECAR.exe crashed. Terminating twoLevelSystem.sh"
       exit
    fi
done


